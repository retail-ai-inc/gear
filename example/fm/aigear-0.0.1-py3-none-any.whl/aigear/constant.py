# Default value of project init
PROJECT_NAME: str = "template_project"
PROJECT_VERSION: str = "0.0.1"
PROJECT_DESCRIBE: str = ""
